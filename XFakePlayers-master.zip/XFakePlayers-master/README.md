# XFakePlayers 14 beta
An extended fake players for Half-Life and mods (including Counter-Strike)
